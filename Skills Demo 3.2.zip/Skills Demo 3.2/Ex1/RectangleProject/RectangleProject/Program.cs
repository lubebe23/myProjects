﻿
/*  Author: Lewis Ubebe
 *  Title: Maths Utilities
 *  Description: The program will allow a user to input the length width and colour of a rectangle
 *  to the console which will in turn return the area followed by the colour
 */
namespace RectangleProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            rectangle myRectangle = new rectangle();

            Console.WriteLine("Enter Rectangle Length: ");
            myRectangle.length = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Rectangle Width: ");
            myRectangle.width = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Rectangle Colour");
            myRectangle.colour = Console.ReadLine();
            Console.WriteLine("The area of this rectangle is " + myRectangle.getArea() + " cm squared");
            Console.WriteLine("The colour of the rectangle is " + myRectangle.colour);
        }
        /// <summary>
        /// This class will allow us to get the volume and colour of our rectantgle
        /// </summary>
        class rectangle
        {

            public int length { get; set; }

            public int width { get; set; }

            public string colour { get; set; }

            /// <summary>
            /// Utility to calculate area of rectangle
            /// </summary>
            /// <returns>Area of rectangle</returns>
            public int getArea()
            {
                return length * width;
            }
        }
    }
}