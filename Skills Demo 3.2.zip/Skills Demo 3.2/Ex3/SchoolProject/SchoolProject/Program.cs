﻿/*  Author: Lewis Ubebe
 *  Title: School Project
 *  Description: Describes a worker in a system of wages and information
 */


namespace SchoolProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Worker worker1 = new Worker();
            worker1.Name = "Paul Ryan";
            worker1.Job = "Manager";
            worker1.YearsService = 18;
            worker1.QualificationLevel = 4;
            Console.WriteLine(worker1.DisplayWorkerInfo());

            Console.WriteLine();

            Worker worker2 = new Worker();
            worker2.Name = "Tommy Bullfinch";
            worker2.Job = "Caretaker";
            worker2.YearsService = 8;
            worker2.QualificationLevel = 9;
            Console.WriteLine(worker2.DisplayWorkerInfo());
        }
    }
    /// <summary>
    /// Describes a worker in a system of wages and information
    /// </summary>
    class Worker
    {

    /// <summary>
    /// Name of worker
    /// </summary>
    public string Name { get; set; }
   

    
    public string Job { get; set; }
        /// <summary>
        /// Job of worker
        /// </summary>

        public int YearsService { get; set; }
        
        
        /// <summary>
        /// Integer Scale between 1 and 10
        /// </summary>
        public int QualificationLevel { get; set; }
        
        
        /// <summary>
        /// Calculates the worker wage based on props
        /// </summary>
        /// <returns> Double value with wage of worker</returns>
        public double CalculateWage()
        {
            double wage = 1000;

            //position bonus

            if (this.Job == "Teacher")
            {
                wage = wage + 50;
            }
            else if (this.Job == "Manager")
            {
                wage = wage + 150;
            }

            ///Calculate  bonus
            ///
            if (this.YearsService > 15)
            {
                wage = wage + 200;

            }


            //Calculate qualification level

            if (this.QualificationLevel > 5)
            {
                wage = wage + 100;
            }

            else if (this.QualificationLevel > 9)
            {
                wage = wage + 200;
            }

            return wage;
        }
        /// <summary>
        /// displays key info about worker to console
        /// </summary>
        /// <returns> String with worker info</returns>
        public string DisplayWorkerInfo()
        {
            return "Worker name: " + this.Name + Environment.NewLine +
                "Job: " + this.Job + Environment.NewLine +
                "Qualification Level: " + this.QualificationLevel + Environment.NewLine +
                "Weekly Wage: " + this.CalculateWage();
        }
    }


}