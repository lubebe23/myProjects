﻿/*  Author: Lewis Ubebe
 *  Title: Maths Utilities
 *  Description: The user is prompted to select an operation and for each they can input a number and the operation of their choice is carried out
 */

namespace MathsUtilities
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int ans = 0;
            Console.WriteLine("Welcome to Maths Utilities");
            Console.WriteLine("Choose your operation");
            Console.WriteLine("Press '1' for Square Calculator");
            Console.WriteLine("Press '2' for Cube Calculator");
            Console.WriteLine("Or Press '3' for Triangle Area Calculator");
             ans = Convert.ToInt32(Console.ReadLine());
            
                if (ans == 1)
                {
                    Console.WriteLine("Enter the number to be squared: ");
                   double num = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("The number squared is: " + MyMath.SquareANumber(num)); 
                }

                 else if(ans == 2)
                {
                    Console.WriteLine("Enter the number to be cubed: ");
                double num = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("The number cubed is: " + MyMath.CubeANumber(num));
            }

                else if (ans == 3)
                {
                Console.WriteLine("Enter triangle height: ");
                double num1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter triangle width: ");
                double num2 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("The area of this triangle is: " + MyMath.AreaOfTriangle(num1,num2) + "cm squared");
            }
            
        }
        /// <summary>
        /// Method to initiate maths operations
        /// </summary>
        class MyMath
        {
          
            public static double SquareANumber(double x)
            {
                return x * x;
            }

            public static double CubeANumber(double x)
            {
                return x * x * x;
            }

            public static double AreaOfTriangle(double x, double y)
            {
                return (x * y) / 2;
            }
        }
    }
}